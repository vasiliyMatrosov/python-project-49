# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Project Brain-games',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/vasiliyMatrosov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/vasiliyMatrosov/python-project-49/actions)\n\n\n### Maintainability:\n<a href="https://codeclimate.com/github/vasiliyMatrosov/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/23e227cf802a425168e0/maintainability" /></a>\n\n\n### How to install: \n\nmake install\n\nmake build\n\nmake package-install\n\n\n### How to play:\n\nbrain-even \n\ncrain-calc\n\nbrain-gcd\n\nbrain-progression\n\nbrain-prime\n\n\n\nBrain-even:\n<a href="https://asciinema.org/a/Lf2QKhkX4a4PAof1sBd5ZW3QO" target="_blank"><img src="https://asciinema.org/a/Lf2QKhkX4a4PAof1sBd5ZW3QO.svg" /></a>\n\n\nBrain-calc:\n<a href="https://asciinema.org/a/Xd6Yousk4KkFA2Cp5Fn9vUtwM" target="_blank"><img src="https://asciinema.org/a/Xd6Yousk4KkFA2Cp5Fn9vUtwM.svg" /></a>\n\n\nBrain-gcd:\n<a href="https://asciinema.org/a/4eUk0Oc8pRkpeIhJrg1DO3Nvv" target="_blank"><img src="https://asciinema.org/a/4eUk0Oc8pRkpeIhJrg1DO3Nvv.svg" /></a>\n\n\nBrain-progression:\n<a href="https://asciinema.org/a/oQDRVeSBlKMMDK0KlWrISynNN" target="_blank"><img src="https://asciinema.org/a/oQDRVeSBlKMMDK0KlWrISynNN.svg" /></a>\n\n\nBrain-prime\n<a href="https://asciinema.org/a/6xBDo4tLrlh94Hh2LDnxnGNXx" target="_blank"><img src="https://asciinema.org/a/6xBDo4tLrlh94Hh2LDnxnGNXx.svg" /></a>',
    'author': 'vasiliyMatrosov',
    'author_email': 'vasilii.matrosov.91@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
