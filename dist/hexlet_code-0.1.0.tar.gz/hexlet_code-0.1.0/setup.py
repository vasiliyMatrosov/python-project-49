# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Project Brain-games',
    'long_description': '# Hexlet tests and linter status:\n[![Actions Status](https://github.com/vasiliyMatrosov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/vasiliyMatrosov/python-project-49/actions)\n\n\n# Maintainability:\n<a href="https://codeclimate.com/github/vasiliyMatrosov/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/23e227cf802a425168e0/maintainability" /></a>\n\n# Description\nProject containing 5 mini-games, each game is started by commands.\n\n\n***\n\n## For the correct operation of the games you will need: Python v3.6 and higher, Poetry v1.2.0 and higher\n\n\n\n***\n\n### How to install: \nGit clone https://github.com/vasiliyMatrosov/python-project-49\n\nmake install - to install poetry packages.\nmake build - to build your packages inside your project.\nmake publish - It will let us execute the publish command knowing exactly what is going into the build.\nmake package - install installs the built package from our OS, so we can start using simple shell commands.\n\ntest your application by adding brain-games to the command line\n\n### How to play:\ninput the commands:\n\n\'\'\'brain-even\'\'\'\n(The essence of the game is as follows: the user is shown a random number. And he needs to answer yes if the number is even, or no if it is odd.)\n\n\'\'\'crain-calc\'\'\'\'\n(The essence of the game is as follows: the user is shown a random mathematical expression, for example 35 + 16, which must be calculated and the correct answer written down.)\n\n\'\'\'brain-gcd\'\'\'\n(The essence of the game is as follows: the user is shown two random numbers, for example, 25 50. The user must calculate and enter the greatest common divisor of these numbers.)\n\n\'\'\'brain-progression\'\'\'\n(Show the player a series of numbers that form an arithmetic progression, replacing any of the numbers with two dots. The player must determine this number.\nThe recommended progression length is 10 numbers. The length can be randomly generated, but must contain at least 5 numbers!\nThe position of the hidden element changes each time (selected randomly.))\n\n\'\'\'brain-prime\'\'\'\n(The user is shown numbers and needs to determine if the number is prime. If the number is prime, the user must enter yes, if not, then no.)\n\n***\n\nExample Brain-even:\n<a href="https://asciinema.org/a/Lf2QKhkX4a4PAof1sBd5ZW3QO" target="_blank"><img src="https://asciinema.org/a/Lf2QKhkX4a4PAof1sBd5ZW3QO.svg" /></a>\n\n\nExample Brain-calc:\n<a href="https://asciinema.org/a/Xd6Yousk4KkFA2Cp5Fn9vUtwM" target="_blank"><img src="https://asciinema.org/a/Xd6Yousk4KkFA2Cp5Fn9vUtwM.svg" /></a>\n\n\nExample Brain-gcd:\n<a href="https://asciinema.org/a/4eUk0Oc8pRkpeIhJrg1DO3Nvv" target="_blank"><img src="https://asciinema.org/a/4eUk0Oc8pRkpeIhJrg1DO3Nvv.svg" /></a>\n\n\nExample Brain-progression:\n<a href="https://asciinema.org/a/oQDRVeSBlKMMDK0KlWrISynNN" target="_blank"><img src="https://asciinema.org/a/oQDRVeSBlKMMDK0KlWrISynNN.svg" /></a>\n\n\nExample Brain-prime\n<a href="https://asciinema.org/a/6xBDo4tLrlh94Hh2LDnxnGNXx" target="_blank"><img src="https://asciinema.org/a/6xBDo4tLrlh94Hh2LDnxnGNXx.svg" /></a>',
    'author': 'vasiliyMatrosov',
    'author_email': 'vasilii.matrosov.91@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
