### Hexlet tests and linter status:
[![Actions Status](https://github.com/vasiliyMatrosov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/vasiliyMatrosov/python-project-49/actions)


<a href="https://codeclimate.com/github/vasiliyMatrosov/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/23e227cf802a425168e0/maintainability" /></a>



https://asciinema.org/a/z60n9hv02F2M5FlxnWdbDqYNQ


https://asciinema.org/a/YMMKYyzjy9RFI2UNtQcl6G6ZU


https://asciinema.org/a/Er6xNVD6xvSTVYmh2orsbrEt7


https://asciinema.org/a/p4dI5J0ipE9el5PzaO23ULewJ


https://asciinema.org/a/gXdEorHHYzzbwsfan6HdITlvv