### Hexlet tests and linter status:
[![Actions Status](https://github.com/vasiliyMatrosov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/vasiliyMatrosov/python-project-49/actions)


### Maintainability:
<a href="https://codeclimate.com/github/vasiliyMatrosov/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/23e227cf802a425168e0/maintainability" /></a>


### How to install: 

make install

make build

make package-install


### How to play:

brain-even 

crain-calc

brain-gcd

brain-progression

brain-prime



Brain-even:
<a href="https://asciinema.org/a/Lf2QKhkX4a4PAof1sBd5ZW3QO" target="_blank"><img src="https://asciinema.org/a/Lf2QKhkX4a4PAof1sBd5ZW3QO.svg" /></a>


Brain-calc:
<a href="https://asciinema.org/a/Xd6Yousk4KkFA2Cp5Fn9vUtwM" target="_blank"><img src="https://asciinema.org/a/Xd6Yousk4KkFA2Cp5Fn9vUtwM.svg" /></a>


Brain-gcd:
<a href="https://asciinema.org/a/4eUk0Oc8pRkpeIhJrg1DO3Nvv" target="_blank"><img src="https://asciinema.org/a/4eUk0Oc8pRkpeIhJrg1DO3Nvv.svg" /></a>


Brain-progression:
<a href="https://asciinema.org/a/oQDRVeSBlKMMDK0KlWrISynNN" target="_blank"><img src="https://asciinema.org/a/oQDRVeSBlKMMDK0KlWrISynNN.svg" /></a>


Brain-prime
<a href="https://asciinema.org/a/6xBDo4tLrlh94Hh2LDnxnGNXx" target="_blank"><img src="https://asciinema.org/a/6xBDo4tLrlh94Hh2LDnxnGNXx.svg" /></a>